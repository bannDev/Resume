//------------------------------------------------------------------------------------
//Programmer: Stavros Bannoura
//Date: 12/6/2019
//Resume application project
//
//This is javascript code designed to work on the design and servers of the resume
//inputs. I have included a blur function, and added an email validator in the 
//design. When the user enters an invalid email character the user will be notfied if
//they did not enter a correct format. Once the user has completed all of the required
//inputs to submit the application, a pop up will appear on the canvas and it will show
//the user his resume output. 
//
//
//------------------------------------------------------------------------------------


// Color, font and style of Name, 
document.getElementById("h1").style.color = "red";
document.getElementById("h2").style.color = "red";
document.getElementById("h1").style.font = "Garamond font";
document.getElementById("h2").style.fontStyle = "italicized";

// 
var x = document.getElementById("myEmail");
    x.addEventListener("blur", myBlurFunction, true)

// This is the blur for when the user skips the email address input instructions 
// it then causes it to display "Incorrect Format"
function myBlurFunction() {
    
    var emailValidation =  (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);
    var emailInput = document.getElementById("myEmail").value 
    
  if (emailValidation.test(emailInput) == false) { 
    document.getElementById("incorrectFormat").innerHTML = "Incorrect Format";
}
}

// This will be the input data for the output to display the right format after user
// clicks submit 
function myResumeData()
{
    myName = document.getElementById("myName").value;
    myPhone = document.getElementById("myPhone").value;
    myAddress = document.getElementById("myAddress").value;
    myEmail = document.getElementById("myEmail").value;
    personal = document.getElementById("personal").value;
    myObj = document.getElementById("myObj").value;
    myExp1 = document.getElementById("myExp1").value;
    myExp2 = document.getElementById("myExp2").value;
    myExp3 = document.getElementById("myExp3").value;
    myRef = document.getElementById("myRef").value;
	
	// Resume Output
    myText = ("<html>\n<head>\n<title>Welcome</title>\n"); 
    myText += ("<style>body {font-size:12pt;font-family:verdana;}div#theLeft {clear:both; width:15%;float:left;}div#theRight {width:83%;float:right;padding-bottom:20px;padding-right:30px;}</style>")
    myText += ("</head>\n<body>\n")
    myText += ("<div id='theLeft'>Full Name: </div>") // Output display for the input
    myText += ("<div id='theRight'>"+ myName +"</div>")
    myText += ("<div id='theLeft'>Address: </div>")
    myText += ("<div id='theRight'>"+ myAddress +"</div>")
    myText += ("<div id='theLeft'>Phone Number: </div>")
    myText += ("<div id='theRight'>"+ myPhone +"</div>")
    myText += ("<div id='theLeft'>Email Address: </div>")
    myText += ("<div id='theRight'>"+ myEmail +"</div>")
    myText += ("<div id='theLeft'>Personal Information: </div>")
    myText += ("<div id='theRight'>"+ personal +"</div>")  // Displays users input
    myText += ("<div id='theLeft'>Career Objectives: </div>")
    myText += ("<div id='theRight'>"+ myObj +"</div>")
    myText += ("<div id='theLeft'>Prior employment experience: </div>")
    myText += ("<div id='theRight'>"+ myExp1 +"</div>")
    myText += ("<div id='theLeft'>Prior employment experience: </div>")
    myText += ("<div id='theRight'>"+ myExp2 +"</div>")
    myText += ("<div id='theLeft'>Prior employment experience: </div>")
    myText += ("<div id='theRight'>"+ myExp3 +"</div>")
    myText += ("<div id='theLeft'>Reference of past experience: </div>")
    myText += ("<div id='theRight'>"+ myRef +"</div>")
    myText += ("</body>\n</html>");
    
	// Pop up of the resume submission output
    flyWindow = window.open('about:blank','myPop','width=400,height=200,left=200,top=200');
    flyWindow.document.write(myText); 
}


